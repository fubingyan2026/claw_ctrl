Extract all files. Install SEGGER J-Link if needed: https://www.segger.com/downloads/jlink/
Power the board, connect J-Link SWD, then double-click flash-factory.cmd.
Factory flashing erases all flash, including existing parameters and boot counts.
