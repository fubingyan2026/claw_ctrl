#ifndef DRV_FILL_LIGHT_H
#define DRV_FILL_LIGHT_H
#include <stdint.h>
#define DRV_FILL_LIGHT_LEVEL_MAX 1000U
/* PA6 / TIMER2_CH0, active high, 0..1000. Default off. */
void drv_fill_light_init(void);
void drv_fill_light_set(uint16_t level);
/* Last applied PWM setpoint, not measured optical output. */
uint16_t drv_fill_light_get(void);
#endif
