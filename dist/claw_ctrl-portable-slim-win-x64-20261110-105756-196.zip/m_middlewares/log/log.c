/**
 * @file    log.c
 * @author  G1_Hand 项目组
 * @version V1.0.0
 * @date    2026 6 12
 * @brief   日志模块实现（ESP32风格日志输出）
 * @attention
 *
 * Copyright (c) 2026 G1_Hand 项目组.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 *
 */

/* Includes ------------------------------------------------------------------*/
#include "log.h"

#include <stdarg.h>
#include <string.h>

#include "printf.h"

/* Private constants ---------------------------------------------------------*/

/** @brief 日志级别对应的单字符标识 */
static const char* const s_level_chars[] = {
    "N", /**< NONE */
    "E", /**< ERROR */
    "W", /**< WARN */
    "I", /**< INFO */
    "D", /**< DEBUG */
    "T", /**< TRACE */
};

/** @brief 日志级别对应的 ANSI 颜色码 */
static const char* const s_level_colors[] = {
    LOG_COLOR_RESET, /**< NONE */
    LOG_COLOR_RED, /**< ERROR - 红色 */
    LOG_COLOR_YELLOW, /**< WARN - 黄色 */
    LOG_COLOR_GREEN, /**< INFO - 绿色 */
    LOG_COLOR_WHITE, /**< DEBUG - 蓝色 */
    LOG_COLOR_GRAY, /**< TRACE - 无颜色 */
};

/* Private variables ---------------------------------------------------------*/

/**
 * @brief 输出 FIFO 缓冲区
 * @note 格式化缓冲不再使用模块级静态数组：log_log 可能被主循环与中断
 *       上下文同时调用，共享静态缓冲会被 ISR 踩踏产生乱码。改为每调用
 *       使用栈上缓冲（见 log_format_output / log_hexdump）。
 */
static uint8_t s_log_tx_buffer[LOG_DEFAULT_TX_BUFFER_SIZE];

/** @brief 输出 FIFO 实例 */
static kfifo_t s_tx_fifo;

/** @brief 当前日志级别 */
static uint8_t s_current_level = LOG_DEFAULT_LEVEL;

/** @brief TX 输出暂停标志（dump 期间屏蔽实时日志） */
static bool s_output_held = false;

/** @brief 初始化标志 */
static bool s_initialized = false;

/** @brief 日志落盘回调（由外部通过 log_set_flash_sink_cb 注册） */
static log_flash_sink_cb_t s_flash_sink_cb = NULL;

/** @brief 模块配置实例 */
static log_config_t s_config = {
    .name = "log",
    .tx_buffer = s_log_tx_buffer,
    .tx_buffer_size = sizeof(s_log_tx_buffer),
    .get_timestamp_cb = NULL,
    .format_buffer_size = LOG_DEFAULT_FORMAT_BUFFER_SIZE,
    .default_level = LOG_DEFAULT_LEVEL,
    .enable_color = LOG_DEFAULT_ENABLE_COLOR,
    .enable_timestamp = LOG_DEFAULT_ENABLE_TIMESTAMP,
};

/* Private function prototypes -----------------------------------------------*/

/**
 * @brief 格式化并输出日志到 FIFO
 * @param level 日志级别
 * @param tag 日志标签
 * @param fmt 格式化字符串
 * @param args 可变参数列表
 * @return 操作结果错误码
 */
static log_error_t log_format_output(log_level_t level, const char* tag,
    const char* fmt, va_list args);

/* Exported functions --------------------------------------------------------*/

/**
 * @brief 初始化日志模块
 * @param config 配置结构体指针
 * @return 操作结果错误码
 */
log_error_t log_init(const log_config_t* config)
{
    if (!config) {
        return LOG_ERROR_NULL_PTR;
    }

    if (s_initialized) {
        log_deinit();
    }

    s_config.get_timestamp_cb = config->get_timestamp_cb;
    s_config.name = config->name ? config->name : "log";
    s_config.tx_buffer = config->tx_buffer ? config->tx_buffer : s_log_tx_buffer;
    s_config.tx_buffer_size = config->tx_buffer ? config->tx_buffer_size : sizeof(s_log_tx_buffer);
    if (s_config.tx_buffer_size < 2U || (s_config.tx_buffer_size & (s_config.tx_buffer_size - 1U)) != 0U) { return LOG_ERROR_INVALID_PARAM; }
    s_config.default_level = config->default_level;
    s_config.enable_color = config->enable_color;
    s_config.enable_timestamp = config->enable_timestamp;
    s_config.format_buffer_size = (config->format_buffer_size > 0U && config->format_buffer_size <= LOG_DEFAULT_FORMAT_BUFFER_SIZE) ? config->format_buffer_size : LOG_DEFAULT_FORMAT_BUFFER_SIZE;
    s_current_level = config->default_level;
    s_output_held = false;

    kfifo_init(&s_tx_fifo, s_config.tx_buffer, s_config.tx_buffer_size, NULL);

    s_initialized = true;

    return LOG_OK;
}

/**
 * @brief 反初始化日志模块
 */
void log_deinit(void)
{
    s_config.name = "log";
    s_config.tx_buffer = NULL;
    s_config.get_timestamp_cb = NULL;
    s_config.tx_buffer_size = 0;
    s_config.format_buffer_size = LOG_DEFAULT_FORMAT_BUFFER_SIZE;
    s_config.default_level = LOG_DEFAULT_LEVEL;
    s_config.enable_color = LOG_DEFAULT_ENABLE_COLOR;
    s_config.enable_timestamp = LOG_DEFAULT_ENABLE_TIMESTAMP;
    s_current_level = LOG_DEFAULT_LEVEL;
    s_flash_sink_cb = NULL;
    kfifo_reset(&s_tx_fifo);
    s_initialized = false;
}

/**
 * @brief 检查日志模块是否已初始化
 * @return true表示已初始化，false表示未初始化
 */
bool log_is_initialized(void)
{
    return s_initialized;
}

/**
 * @brief 设置日志级别
 * @param level 日志级别
 * @return 操作结果错误码
 */
log_error_t log_set_level(log_level_t level)
{
    if (!s_initialized) {
        return LOG_ERROR_UNINITIALIZED;
    }

    if (level > LOG_LEVEL_TRACE) {
        return LOG_ERROR_INVALID_PARAM;
    }

    s_current_level = level;

    return LOG_OK;
}

/**
 * @brief 获取当前日志级别
 * @return 当前日志级别
 */
log_level_t log_get_level(void)
{
    if (!s_initialized) {
        return LOG_LEVEL_NONE;
    }

    return (log_level_t)s_current_level;
}

/**
 * @brief 启用或禁用颜色输出
 * @param enable true启用，false禁用
 * @return 操作结果错误码
 */
log_error_t log_set_color_enable(bool enable)
{
    if (!s_initialized) {
        return LOG_ERROR_UNINITIALIZED;
    }

    s_config.enable_color = enable;

    return LOG_OK;
}

/**
 * @brief 启用或禁用时间戳
 * @param enable true启用，false禁用
 * @return 操作结果错误码
 */
log_error_t log_set_timestamp_enable(bool enable)
{
    if (!s_initialized) {
        return LOG_ERROR_UNINITIALIZED;
    }

    s_config.enable_timestamp = enable;

    return LOG_OK;
}

/**
 * @brief 暂停/恢复格式化日志（LOG_* 与 hexdump）的 TX 输出
 * @param hold true=暂停（仅 log_write 仍可输出），false=恢复
 * @return 操作结果错误码
 */
log_error_t log_hold_output(bool hold)
{
    if (!s_initialized) {
        return LOG_ERROR_UNINITIALIZED;
    }

    s_output_held = hold;

    return LOG_OK;
}

/**
 * @brief 注册日志落盘回调（Flash 持久化钩子）
 * @param cb 回调函数指针（NULL=取消注册）
 * @return 操作结果错误码
 */
log_error_t log_set_flash_sink_cb(log_flash_sink_cb_t cb)
{
    if (!s_initialized) {
        return LOG_ERROR_UNINITIALIZED;
    }

    s_flash_sink_cb = cb;

    return LOG_OK;
}

/**
 * @brief 日志输出
 * @param level 日志级别
 * @param tag 日志标签
 * @param fmt 格式化字符串
 * @param ... 可变参数
 * @return 操作结果错误码
 */
log_error_t log_log(log_level_t level, const char* tag, const char* fmt, ...)
{
    if (!fmt) {
        return LOG_ERROR_NULL_PTR;
    }

    if (!s_initialized) {
        return LOG_ERROR_UNINITIALIZED;
    }

    if (level > s_current_level) {
        return LOG_OK;
    }

    va_list args;
    va_start(args, fmt);
    log_error_t result = log_format_output(level, tag, fmt, args);
    va_end(args);

    return result;
}

/**
 * @brief 十六进制转储输出
 * @param tag 日志标签
 * @param data 数据指针
 * @param len 数据长度
 * @return 操作结果错误码
 */
log_error_t log_hexdump(const char* tag, const uint8_t* data, uint32_t len)
{
    (void)tag;

    if (!data) {
        return LOG_ERROR_NULL_PTR;
    }

    if (!s_initialized) {
        return LOG_ERROR_UNINITIALIZED;
    }

    if (len == 0) {
        return LOG_OK;
    }

    /* TX 暂停期间丢弃实时十六进制转储（不触发落盘钩子，属实时诊断输出） */
    if (s_output_held) {
        return LOG_OK;
    }

    /* 每调用使用栈上缓冲（重入安全：log_log 可在 ISR 与主循环并发调用） */
    char buf[LOG_DEFAULT_FORMAT_BUFFER_SIZE];
    uint16_t buf_size = s_config.format_buffer_size;
    uint32_t offset = 0;

    for (uint32_t i = 0; i < len; i += 16) {
        offset = 0;

        offset += snprintf_(buf + offset, buf_size - offset, "%04lX: ", (unsigned long)i);

        for (uint32_t j = 0; j < 16; j++) {
            if (i + j < len) {
                offset += snprintf_(buf + offset, buf_size - offset, "%02X ", data[i + j]);
            } else {
                offset += snprintf_(buf + offset, buf_size - offset, "   ");
            }

            if (j == 7) {
                offset += snprintf_(buf + offset, buf_size - offset, " ");
            }
        }

        offset += snprintf_(buf + offset, buf_size - offset, " |");

        for (uint32_t j = 0; j < 16 && i + j < len; j++) {
            char c = (char)data[i + j];
            if (c >= 0x20 && c <= 0x7E) {
                offset += snprintf_(buf + offset, buf_size - offset, "%c", c);
            } else {
                offset += snprintf_(buf + offset, buf_size - offset, ".");
            }
        }

        offset += snprintf_(buf + offset, buf_size - offset, "|\r\n");

        kfifo_put(&s_tx_fifo, (const uint8_t*)buf, offset);
    }

    return LOG_OK;
}

/**
 * @brief 原始数据输出（不添加格式）
 * @param data 数据指针
 * @param len 数据长度
 * @return 操作结果错误码
 */
log_error_t log_write(const uint8_t* data, uint32_t len)
{
    if (!data) {
        return LOG_ERROR_NULL_PTR;
    }

    if (!s_initialized) {
        return LOG_ERROR_UNINITIALIZED;
    }

    if (len == 0) {
        return LOG_OK;
    }

    kfifo_put(&s_tx_fifo, data, len);

    return LOG_OK;
}

/**
 * @brief 获取输出缓冲区中的数据长度
 * @return 缓冲区中的数据长度，未初始化返回0
 */
uint32_t log_tx_len(void)
{
    if (!s_initialized) {
        return 0;
    }

    return kfifo_len(&s_tx_fifo);
}

/**
 * @brief 获取输出缓冲区剩余可写空间
 * @return 可写入的字节数，未初始化返回0
 */
uint32_t log_tx_avail(void)
{
    if (!s_initialized) {
        return 0;
    }

    return kfifo_avail(&s_tx_fifo);
}

/**
 * @brief 从输出缓冲区取出数据
 * @param buffer 目标缓冲区
 * @param len 期望取出的长度
 * @return 实际取出的长度
 */
uint32_t log_tx_get(uint8_t* buffer, uint32_t len)
{
    if (!buffer || len == 0) {
        return 0;
    }

    if (!s_initialized) {
        return 0;
    }

    return kfifo_get(&s_tx_fifo, buffer, len);
}

/**
 * @brief 断言失败处理函数
 * @param func 函数名
 * @param line 行号
 */
void log_assert_failed(const char* func, uint32_t line)
{
    LOG_E("ASSERT FAILED: %s:%lu", func ? func : "unknown", (unsigned long)line);
    for (;;) {
    }
}

/**
 * @brief 格式化并输出日志到 FIFO
 * @param level 日志级别
 * @param tag 日志标签
 * @param fmt 格式化字符串
 * @param args 可变参数列表
 * @return 操作结果错误码
 */
static log_error_t log_format_output(log_level_t level, const char* tag,
    const char* fmt, va_list args)
{
    /* 每调用使用栈上缓冲（重入安全：本函数可能在 ISR 上下文执行，
       与主循环的 log_log 并发调用时共享静态缓冲会被踩踏产生乱码） */
    char buf[LOG_DEFAULT_FORMAT_BUFFER_SIZE];
    uint16_t buf_size = s_config.format_buffer_size;
    uint32_t offset = 0;

    if (level > LOG_LEVEL_TRACE) {
        level = LOG_LEVEL_TRACE;
    }

    const char* level_char = s_level_chars[level];
    const char* level_color = s_level_colors[level];

    if (tag == NULL) {
        tag = s_config.name;
    }

    if (s_config.enable_color) {
        offset += snprintf_(buf + offset, buf_size - offset, "%s", level_color);
    }

    offset += snprintf_(buf + offset, buf_size - offset, "%s (", level_char);

    if (s_config.enable_timestamp) {
        static uint32_t timestamp = 0;
        if (s_config.get_timestamp_cb) {
            timestamp = s_config.get_timestamp_cb();
        } else {
            timestamp++;
        }
        offset += snprintf_(buf + offset, buf_size - offset, "%lu",
            (unsigned long)timestamp);
    }

    offset += snprintf_(buf + offset, buf_size - offset, ") %s: ", tag);

    int msg_len = vsnprintf_(buf + offset, buf_size - offset, fmt, args);
    if (msg_len < 0) {
        return LOG_ERROR_INVALID_PARAM;
    }

    offset += msg_len;
    if (offset >= buf_size) {
        offset = buf_size - 1;
    }

    if (s_config.enable_color) {
        offset += snprintf_(buf + offset, buf_size - offset, "%s", LOG_COLOR_RESET);
    }

    offset += snprintf_(buf + offset, buf_size - offset, "\r\n");

    /* TX 暂停期间（如 Flash 日志 dump）屏蔽实时日志输出；落盘钩子不受影响 */
    if (!s_output_held) {
        kfifo_put(&s_tx_fifo, (const uint8_t*)buf, offset);
    }

    /* 落盘钩子：将格式化后的日志行同步上抛给已注册的 Flash 持久化回调，
       暂停 TX 期间 WARN/ERROR 仍持久化不丢失 */
    if (s_flash_sink_cb != NULL) {
        s_flash_sink_cb(level, buf, offset);
    }

    return LOG_OK;
}
