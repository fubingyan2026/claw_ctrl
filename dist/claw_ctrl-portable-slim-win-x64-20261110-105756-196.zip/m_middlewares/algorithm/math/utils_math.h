/*
        Copyright 2016 - 2019 Benjamin Vedder	benjamin@vedder.se

        This file is part of the VESC firmware.

        The VESC firmware is free software: you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation, either version 3 of the License, or
        (at your option) any later version.

        The VESC firmware is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.

        You should have received a copy of the GNU General Public License
        along with this program.  If not, see <http://www.gnu.org/licenses/>.
        */

#ifndef UTILS_MATH_H_
#define UTILS_MATH_H_

#include <stdbool.h>
#include <stdint.h>

#include "math.h"

#define PI 3.14159265358979323846f
#define TWO_PI 6.28318530717958647692f

float utils_map_angle(float angle, float min, float max);
void utils_deadband(float* value, float tres, float max);
float utils_angle_difference_rad(float angle1, float angle2);
float utils_interpolate_angles_rad(float a1, float a2, float weight_a1);
float utils_middle_of_3(float a, float b, float c);
int utils_middle_of_3_int(int a, int b, int c);
float utils_min_abs(float va, float vb);
float utils_max_abs(float va, float vb);
void utils_byte_to_binary(int x, char* b);
float utils_throttle_curve(float val, float curve_acc, float curve_brake, int mode);
void utils_fft32_bin0(const float* real_in, float* real, float* imag);
void utils_fft32_bin1(float* real_in, float* real, float* imag);
void utils_fft32_bin2(float* real_in, float* real, float* imag);
void utils_fft16_bin0(float* real_in, float* real, float* imag);
void utils_fft16_bin1(float* real_in, float* real, float* imag);
void utils_fft16_bin2(float* real_in, float* real, float* imag);
void utils_fft8_bin0(float* real_in, float* real, float* imag);
void utils_fft8_bin1(float* real_in, float* real, float* imag);
void utils_fft8_bin2(float* real_in, float* real, float* imag);
float utils_batt_liion_norm_v_to_capacity(float norm_v);
uint16_t utils_median_filter_uint16_run(uint16_t* buffer,
    unsigned int* buffer_index, unsigned int filter_len, uint16_t sample);
void utils_rotate_vector3(float* input, float* rotation, float* output, bool reverse);

// Return the sign of the argument. -1.0 if negative, 1.0 if zero or positive.
#define SIGN(x) (((x) < 0.0f) ? -1.0f : 1.0f)

// Squared
#define SQ(x) ((x) * (x))

// Two-norm of 2D vector
// #define NORM2(x,y)		(sqrt(SQ(x) + SQ(y)))
#define NORM2_f(x, y) (sqrtf(SQ(x) + SQ(y)))

// nan and infinity check for floats
#define UTILS_IS_INF(x) ((x) == (1.0f / 0.0f) || (x) == (-1.0f / 0.0f))
#define UTILS_IS_NAN(x) ((x) != (x))
#define UTILS_NAN_ZERO(x) (x = UTILS_IS_NAN(x) ? 0.0f : x)

// Handy conversions for radians/degrees and RPM/radians-per-second
#define DEG2RAD_f(deg) ((deg) * (float)(M_PI / 180.0f))
#define RAD2DEG_f(rad) ((rad) * (float)(180.0f / M_PI))
#define RPM2RADPS_f(rpm) ((rpm) * (float)((2.0f * M_PI) / 60.0f))
#define RADPS2RPM_f(rad_per_sec) ((rad_per_sec) * (float)(60.0f / (2.0f * M_PI)))

#ifndef MIN
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#endif

// For double precision literals
#define D(x) ((double)x##L)

/**
 * A simple low pass filter.
 *
 * @param value
 * The filtered value.
 *
 * @param sample
 * Next sample.
 *
 * @param filter_constant
 * Filter constant. Range 0.0 to 1.0, where 1.0 gives the unfiltered value.
 */
#define UTILS_LP_FAST(value, sample, filter_constant) (value -= (filter_constant) * ((value) - (sample)))

/**
 * A fast approximation of a moving average filter with N samples. See
 * https://en.wikipedia.org/wiki/Moving_average#Exponential_moving_average
 * https://en.wikipedia.org/wiki/Exponential_smoothing
 *
 * It is not entirely the same as it behaves like an IIR filter rather than a FIR filter, but takes
 * much less memory and is much faster to run.
 */
#define UTILS_LP_MOVING_AVG_APPROX(value, sample, N) UTILS_LP_FAST(value, sample, 2.0 / ((N) + 1.0))

// Constants
#define ONE_BY_SQRT3 (0.57735026919f)
#define TWO_BY_SQRT3 (2.0f * 0.57735026919f)
#define SQRT3_BY_2 (0.86602540378f)
#define COS_30_DEG (0.86602540378f)
#define SIN_30_DEG (0.5f)
#define COS_MINUS_30_DEG (0.86602540378f)
#define SIN_MINUS_30_DEG (-0.5f)
#define ONE_BY_SQRT2 (0.7071067811865475f)

// Inline functions
static inline void utils_step_towards(float* value, float goal, float step)
{
    if (*value < goal) {
        if ((*value + step) < goal) {
            *value += step;
        } else {
            *value = goal;
        }
    } else if (*value > goal) {
        if ((*value - step) > goal) {
            *value -= step;
        } else {
            *value = goal;
        }
    }
}

/**
 * Make sure that -pi <= angle < pi,
 *
 * @param theta
 * The angle to normalize in radians.
 * WARNING: Don't use too large angles.
 */
static inline void utils_norm_angle_rad(float* theta)
{
    const float INV_TWO_PI = 1.0f / TWO_PI;
    if (*theta > PI) {
        // 将除法替换为乘法
        *theta -= TWO_PI * (float)(int32_t)((*theta + PI) * INV_TWO_PI);
    } else if (*theta < -PI) {
        // 将除法替换为乘法
        *theta += TWO_PI * (float)(int32_t)((-*theta + PI) * INV_TWO_PI);
    }
}

/**
 * Make sure that 0 <= angle < 2*PI,
 *
 * @param angle
 * The angle to normalize in radians.
 * WARNING: Don't use too large angles to avoid integer overflow during conversion.
 */
static inline void utils_norm_angle_0_2pi(float* angle)
{
    // 定义 1 / (2*PI) 的常数，编译器通常会在编译期将其直接计算为常量
    const float INV_TWO_PI = 1.0f / TWO_PI;

    // 统一进行截断减法
    *angle -= TWO_PI * (float)(int32_t)(*angle * INV_TWO_PI);

    // 如果原角为负数，减去负数的截断值后仍会是负数（例如 -0.1 * TWO_PI 仍为 -0.1 * TWO_PI）
    // 此时只需简单加上一个 TWO_PI 即可。
    // 注：若原角刚好是 -TWO_PI，计算后会直接变为 0.0f，不会触发此分支。
    if (*angle < 0.0f) {
        *angle += TWO_PI;
    }
}

static inline void utils_truncate_number(float* number, const float min, const float max)
{
    if (*number > max) {
        *number = max;
    } else if (*number < min) {
        *number = min;
    }
}

static inline void utils_truncate_number_int(int* number, const int min, const int max)
{
    if (*number > max) {
        *number = max;
    } else if (*number < min) {
        *number = min;
    }
}

static inline void utils_truncate_number_abs(float* number, float max)
{
    if (*number > max) {
        *number = max;
    } else if (*number < -max) {
        *number = -max;
    }
}

static inline float utils_map(float x, float in_min, float in_max, float out_min, float out_max)
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

static inline int utils_map_int(int x, int in_min, int in_max, int out_min, int out_max)
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

/**
 * Truncate the magnitude of a vector.
 *
 * @param x
 * The first component.
 *
 * @param y
 * The second component.
 *
 * @param max
 * The maximum magnitude.
 *
 * @return
 * True if saturation happened, false otherwise
 */
static inline bool utils_saturate_vector_2d(float* x, float* y, float max)
{
    bool retval = false;
    float mag = NORM2_f(*x, *y);
    max = fabsf(max);

    if (mag < 0.0f) {
        mag = 0.0f;
    }

    if (mag > max) {
        const float f = max / mag;
        *x *= f;
        *y *= f;
        retval = true;
    }

    return retval;
}

/* ===================== 通用边沿检测（E1_PRO 追加） ===================== */

/**
 * @brief 数字信号边沿检测状态
 * @note  valid=0 表示尚未建立基线；首次 utils_edge_detect() 仅建基线并返回 NONE
 */
typedef struct {
    bool prev;  /**< 上一次采样值 */
    bool valid; /**< 基线已建立标志 */
} utils_edge_det_t;

/**
 * @brief 边沿事件
 */
typedef enum {
    UTILS_EDGE_NONE = 0, /**< 无变化（或尚未建立基线） */
    UTILS_EDGE_RISING,   /**< 上升沿：0 → 1 */
    UTILS_EDGE_FALLING,  /**< 下降沿：1 → 0 */
} utils_edge_t;

/**
 * @brief 复位边沿检测状态（清除基线，下次采样重新建立基线）
 * @param det 边沿检测状态指针（不可为 NULL）
 */
void utils_edge_det_init(utils_edge_det_t* det);

/**
 * @brief 周期采样并返回边沿事件（通用，供轮询类输入复用）
 * @param det    边沿检测状态指针（不可为 NULL）
 * @param sample 本次采样电平（true=高/有效, false=低/无效）
 * @return UTILS_EDGE_RISING 上升沿 / UTILS_EDGE_FALLING 下降沿 / UTILS_EDGE_NONE 无变化或未建基线
 * @note  首次调用只建立基线返回 NONE；之后每次调用比较本次与上次采样值
 */
utils_edge_t utils_edge_detect(utils_edge_det_t* det, bool sample);

#endif /* UTILS_MATH_H_ */
